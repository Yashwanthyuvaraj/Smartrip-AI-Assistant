
const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Yash@2104',
  database: 'SmartTrip'
});

db.connect(err => {
  if (err) {
    console.error("❌ MySQL error:", err.message);
    return;
  }
  console.log("✅ Connected to MySQL");
});

app.post("/api/auth/register", (req, res) => {
  const { name, email, password } = req.body;
  const hashed = bcrypt.hashSync(password, 10);
  const sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";

  db.query(sql, [name, email, hashed], (err) => {
    if (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        return res.status(400).json({ message: "An account with this email already exists." });
      }
      console.error("Registration error:", err);
      return res.status(500).json({ message: "Server error. Please try again." });
    }
    res.json({ message: "User registered successfully" });
  });
});


app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body;
  const sql = "SELECT * FROM users WHERE email = ?";
  db.query(sql, [username], (err, results) => {
    if (err || results.length === 0) return res.status(400).json({ message: "Invalid credentials" });
    const user = results[0];
    const isMatch = bcrypt.compareSync(password, user.password);
    if (!isMatch) return res.status(401).json({ message: "Invalid password" });

    const token = jwt.sign({ id: user.id, email: user.email }, "secret123", { expiresIn: '1h' });
    res.json({ message: "Login successful", token, user: { name: user.name, email: user.email } });
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
